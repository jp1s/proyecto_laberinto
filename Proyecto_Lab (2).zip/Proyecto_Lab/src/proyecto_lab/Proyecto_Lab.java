/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto_lab;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Proyecto_Lab {
// Definición de variables y métodos principales
   static Scanner sc = new Scanner(System.in);

    /* if (i < n) {
    if (j < n) {
    if (i == 0 | j == 0 | i == n-1 | j == n-1) {
    L[i][j] = "#";
    } else {
    random = (int) (Math.random() * 10 + 1);
    if(random<=2){
    L[i][j] = "#";
    }else{
    L[i][j] = "\033[37m"+"⬜";
    }
    }
    generarLaberinto(L,n,i,j+1);
    }
    generarLaberinto(L,n,i+1,0);
    }*/
   
   // Método para generar el laberinto con dimensiones, casillas especiales y obstáculos
    public static void generarLaberinto(String[][] L, int[] n, int i, int j, int[] inf) {
        int random;
        if (i < n[0]) {
            if (j < n[0]) {
                if (i == 0 | j == 0 | i == n[0] - 1 | j == n[0] - 1) {
                    L[i][j] = "\033[35m" + "⬛";
                } else if (i == inf[1] & j == inf[0]) {
                    L[i][j] = "\033[37m" + "⬜";
                } else if (i == inf[3] & j == inf[2]) {
                    L[i][j] = "\033[33m" + "🏴";
                } else {
                    random = (int) (Math.random() * 100 + 1);
                    if (random <= 50) {
                        L[i][j] = "\033[35m" + "⬛";
                    } else {
                        L[i][j] = "\033[37m" + "⬜";
                    }
                }
                generarLaberinto(L, n, i, j + 1, inf);
            } else {
                generarLaberinto(L, n, i + 1, 0, inf);
            }
        }
    }
// Método para escribir el laberinto en la consola

    public static void escribirLaberinto(String[][] L, int[] n, int i, int j) {

        if (i < n[0]) {
            if (j < n[0]) {
                System.out.print(L[i][j]);
                System.out.print("");
                escribirLaberinto(L, n, i, j + 1);
            } else {
                System.out.println();
                escribirLaberinto(L, n, i + 1, 0);
            }
        }
    }
// Método para dibujar la solución al laberinto
    public static boolean dibujarSolucion(int prevX, int prevY, int actX, int actY, String[][] L, int[] n, int[] inf) {
        int op1X = 0, op1Y = 0, op2X = 0, op2Y = 0, op3X = 0, op3Y = 0, vecinos, delay = 250;
        boolean op1Llena, op2Llena;
        L[actX][actY] = "\033[37m" + "⚪";
        escribirLaberinto(L, n, 0, 0);

        delay = 250;
        try {
            Thread.sleep(delay);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("_____________________________");
        if (actX == inf[3] & actY == inf[2]) {
            L[actX][actY] = "\033[32m" + "⚫";
            escribirLaberinto(L, n, 0, 0);

            delay = 250;
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("_____________________________");
            return true;
        } else {
            vecinos = cantidadPosiciones(actX, actY, L);
            switch (vecinos) {
                case 0 -> {
                    L[actX][actY] = "\033[31m" + "✖";
                    escribirLaberinto(L, n, 0, 0);

                    delay = 250;
                    try {
                        Thread.sleep(delay);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("_____________________________");
                    return false;
                }
                case 1 -> {
                    if ("\033[35m" + "⬛" != (L[actX + 1][actY]) & "\033[31m" + "✖" != (L[actX + 1][actY]) & "\033[37m" + "⚪" != (L[actX + 1][actY]) & (actX + 1 != prevX | actY != prevY)) {
                        op1X = actX + 1;
                        op1Y = actY;
                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY + 1]) & "\033[31m" + "✖" != (L[actX][actY + 1]) & "\033[37m" + "⚪" != (L[actX][actY + 1]) & (actX != prevX | actY + 1 != prevY)) {
                        op1X = actX;
                        op1Y = actY + 1;
                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY - 1]) & ("\033[31m" + "✖" != (L[actX][actY - 1])) & "\033[37m" + "⚪" != (L[actX][actY - 1]) & (actX != prevX | actY - 1 != prevY)) {
                        op1X = actX;
                        op1Y = actY - 1;
                    }
                    if ("\033[35m" + "⬛" != (L[actX - 1][actY]) & "\033[31m" + "✖" != (L[actX - 1][actY]) & "\033[37m" + "⚪" != (L[actX - 1][actY]) & (actX - 1 != prevX | actY != prevY)) {
                        op1X = actX - 1;
                        op1Y = actY;
                    }
                    if (dibujarSolucion(actX, actY, op1X, op1Y, L, n, inf)) {
                        L[actX][actY] = "\033[32m" + "⚫";
                        escribirLaberinto(L, n, 0, 0);

                        delay = 250;
                        try {
                            Thread.sleep(delay);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        System.out.println("_____________________________");
                        return true;
                    } else {
                        L[actX][actY] = "\033[31m" + "✖";
                        escribirLaberinto(L, n, 0, 0);

                        delay = 250;
                        try {
                            Thread.sleep(delay);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        System.out.println("_____________________________");
                        return false;
                    }
                }
                case 2 -> {
                    op1Llena = false;
                    if ("\033[35m" + "⬛" != (L[actX + 1][actY]) & "\033[31m" + "✖" != (L[actX + 1][actY]) & "\033[37m" + "⚪" != (L[actX + 1][actY]) & (actX + 1 != prevX | actY != prevY)) {
                        op1X = actX + 1;
                        op1Y = actY;
                        op1Llena = true;
                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY + 1]) & "\033[31m" + "✖" != (L[actX][actY + 1]) & "\033[37m" + "⚪" != (L[actX][actY + 1]) & (actX != prevX | actY + 1 != prevY)) {
                        if (op1Llena) {
                            op2X = actX;
                            op2Y = actY + 1;
                        } else {
                            op1X = actX;
                            op1Y = actY + 1;
                            op1Llena = true;
                        }

                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY - 1]) & "\033[31m" + "✖" != (L[actX][actY - 1]) & "\033[37m" + "⚪" != (L[actX][actY - 1]) & (actX != prevX | actY - 1 != prevY)) {
                        if (op1Llena) {
                            op2X = actX;
                            op2Y = actY - 1;
                        } else {
                            op1X = actX;
                            op1Y = actY - 1;
                        }
                    }
                    if ("\033[35m" + "⬛" != (L[actX - 1][actY]) & "\033[31m" + "✖" != (L[actX - 1][actY]) & "\033[37m" + "⚪" != (L[actX - 1][actY]) & (actX - 1 != prevX | actY != prevY)) {
                        op2X = actX - 1;
                        op2Y = actY;
                    }
                    if (!dibujarSolucion(actX, actY, op1X, op1Y, L, n, inf)) {
                        if ("\033[31m" + "✖" != (L[op2X][op2Y]) & "\033[37m" + "⚪" != (L[op2X][op2Y])) {
                            if (!dibujarSolucion(actX, actY, op2X, op2Y, L, n, inf)) {
                                L[actX][actY] = "\033[31m" + "✖";
                                escribirLaberinto(L, n, 0, 0);

                                delay = 250;
                                try {
                                    Thread.sleep(delay);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                System.out.println("_____________________________");
                                return false;
                            } else {
                                L[actX][actY] = "\033[32m" + "⚫";
                                escribirLaberinto(L, n, 0, 0);

                                delay = 250;
                                try {
                                    Thread.sleep(delay);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                System.out.println("_____________________________");
                                return true;
                            }
                        } else {
                            L[actX][actY] = "\033[31m" + "✖";
                            escribirLaberinto(L, n, 0, 0);

                            delay = 250;
                            try {
                                Thread.sleep(delay);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            System.out.println("_____________________________");
                            return false;
                        }
                    } else {
                        L[actX][actY] = "\033[32m" + "⚫";
                        escribirLaberinto(L, n, 0, 0);

                        delay = 250;
                        try {
                            Thread.sleep(delay);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        System.out.println("_____________________________");
                        return true;
                    }
                }
                case 3 -> {
                    op1Llena = false;
                    op2Llena = false;
                    if ("\033[35m" + "⬛" != (L[actX + 1][actY]) & "\033[31m" + "✖" != (L[actX + 1][actY]) & "\033[37m" + "⚪" != (L[actX + 1][actY]) & (actX + 1 != prevX | actY != prevY)) {
                        op1X = actX + 1;
                        op1Y = actY;
                        op1Llena = true;
                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY + 1]) & "\033[31m" + "✖" != (L[actX][actY + 1]) & "\033[37m" + "⚪" != (L[actX][actY + 1]) & (actX != prevX | actY + 1 != prevY)) {
                        if (op1Llena) {
                            op2X = actX;
                            op2Y = actY + 1;
                            op2Llena = true;
                        } else {
                            op1X = actX;
                            op1Y = actY + 1;
                        }

                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY - 1]) & "\033[31m" + "✖" != (L[actX][actY - 1]) & "\033[37m" + "⚪" != (L[actX][actY - 1]) & (actX != prevX | actY - 1 != prevY)) {
                        if (op2Llena) {
                            op3X = actX;
                            op3Y = actY - 1;
                        } else {
                            op2X = actX;
                            op2Y = actY - 1;
                        }
                    }
                    if ("\033[35m" + "⬛" != (L[actX - 1][actY]) & "\033[31m" + "✖" != (L[actX - 1][actY]) & "\033[37m" + "⚪" != (L[actX - 1][actY]) & (actX - 1 != prevX | actY != prevY)) {
                        op3X = actX - 1;
                        op3Y = actY;
                    }
                    if (!dibujarSolucion(actX, actY, op1X, op1Y, L, n, inf)) {
                        if ("\033[31m" + "✖" != (L[op2X][op2Y]) & "\033[37m" + "⚪" != (L[op2X][op2Y])) {
                            if (!dibujarSolucion(actX, actY, op2X, op2Y, L, n, inf)) {
                                if ("\033[31m" + "✖" != (L[op3X][op3Y]) & "\033[37m" + "⚪" != (L[op3X][op3Y])) {
                                    if (!dibujarSolucion(actX, actY, op3X, op3Y, L, n, inf)) {
                                        L[actX][actY] = "\033[31m" + "✖";
                                        escribirLaberinto(L, n, 0, 0);

                                        delay = 250;
                                        try {
                                            Thread.sleep(delay);
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }
                                        System.out.println("_____________________________");
                                        return false;
                                    } else {

                                        L[actX][actY] = "\033[32m" + "⚫";
                                        escribirLaberinto(L, n, 0, 0);

                                        delay = 250;
                                        try {
                                            Thread.sleep(delay);
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }
                                        System.out.println("_____________________________");
                                        return true;
                                    }
                                } else {
                                    L[actX][actY] = "\033[31m" + "✖";
                                    escribirLaberinto(L, n, 0, 0);

                                    delay = 250;
                                    try {
                                        Thread.sleep(delay);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    System.out.println("_____________________________");
                                    return false;
                                }
                            } else {

                                L[actX][actY] = "\033[32m" + "⚫";
                                escribirLaberinto(L, n, 0, 0);

                                delay = 250;
                                try {
                                    Thread.sleep(delay);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                System.out.println("_____________________________");
                                return true;
                            }
                        } else {
                            L[actX][actY] = "\033[31m" + "✖";
                            escribirLaberinto(L, n, 0, 0);

                            delay = 250;
                            try {
                                Thread.sleep(delay);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            System.out.println("_____________________________");
                            return false;
                        }
                    } else {
                        L[actX][actY] = "\033[32m" + "⚫";
                        escribirLaberinto(L, n, 0, 0);

                        delay = 250;
                        try {
                            Thread.sleep(delay);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        System.out.println("_____________________________");
                        return true;
                    }
                }
            }
        }
        L[actX][actY] = "\033[31m" + "✖";
        return false;
    }
 // Método para contar el número de posiciones disponibles
    public static int cantidadPosiciones(int actX, int actY, String[][] L) {
        int cant = 0;
        if ("\033[35m" + "⬛" != (L[actX + 1][actY]) & "\033[37m" + "⚪" != (L[actX + 1][actY]) & "\033[31m" + "✖" != (L[actX + 1][actY])) {
            cant++;
        }
        if ("\033[35m" + "⬛" != (L[actX][actY - 1]) & "\033[37m" + "⚪" != (L[actX][actY - 1]) & "\033[31m" + "✖" != (L[actX][actY - 1])) {
            cant++;
        }
        if ("\033[35m" + "⬛" != (L[actX][actY + 1]) & "\033[37m" + "⚪" != (L[actX][actY + 1]) & "\033[31m" + "✖" != (L[actX][actY + 1])) {
            cant++;
        }
        if ("\033[35m" + "⬛" != (L[actX - 1][actY]) & "\033[37m" + "⚪" != (L[actX - 1][actY]) & "\033[31m" + "✖" != (L[actX - 1][actY])) {
            cant++;
        }
        return cant;
    }
// Método para probar la solución del laberinto
    public static boolean pruebaSolucion(int prevX, int prevY, int actX, int actY, String[][] L, int[] n, int[] inf) {
        int op1X = 0, op1Y = 0, op2X = 0, op2Y = 0, op3X = 0, op3Y = 0, vecinos, delay = 250;
        boolean op1Llena, op2Llena;
        L[actX][actY] = "\033[37m" + "⚪";
        if (actX == inf[3] & actY == inf[2]) {
            L[actX][actY] = "\033[32m" + "⚫";
            return true;
        } else {
            vecinos = cantidadPosiciones(actX, actY, L);
            switch (vecinos) {
                case 0 -> {
                    L[actX][actY] = "\033[31m" + "✖";
                    return false;
                }
                case 1 -> {
                    if ("\033[35m" + "⬛" != (L[actX + 1][actY]) & "\033[31m" + "✖" != (L[actX + 1][actY]) & "\033[37m" + "⚪" != (L[actX + 1][actY]) & (actX + 1 != prevX | actY != prevY)) {
                        op1X = actX + 1;
                        op1Y = actY;
                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY + 1]) & "\033[31m" + "✖" != (L[actX][actY + 1]) & "\033[37m" + "⚪" != (L[actX][actY + 1]) & (actX != prevX | actY + 1 != prevY)) {
                        op1X = actX;
                        op1Y = actY + 1;
                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY - 1]) & ("\033[31m" + "✖" != (L[actX][actY - 1])) & "\033[37m" + "⚪" != (L[actX][actY - 1]) & (actX != prevX | actY - 1 != prevY)) {
                        op1X = actX;
                        op1Y = actY - 1;
                    }
                    if ("\033[35m" + "⬛" != (L[actX - 1][actY]) & "\033[31m" + "✖" != (L[actX - 1][actY]) & "\033[37m" + "⚪" != (L[actX - 1][actY]) & (actX - 1 != prevX | actY != prevY)) {
                        op1X = actX - 1;
                        op1Y = actY;
                    }
                    if (pruebaSolucion(actX, actY, op1X, op1Y, L, n, inf)) {
                        L[actX][actY] = "\033[32m" + "⚫";
                        return true;
                    } else {
                        L[actX][actY] = "\033[31m" + "✖";
                        return false;
                    }
                }
                case 2 -> {
                    op1Llena = false;
                    if ("\033[35m" + "⬛" != (L[actX + 1][actY]) & "\033[31m" + "✖" != (L[actX + 1][actY]) & "\033[37m" + "⚪" != (L[actX + 1][actY]) & (actX + 1 != prevX | actY != prevY)) {
                        op1X = actX + 1;
                        op1Y = actY;
                        op1Llena = true;
                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY + 1]) & "\033[31m" + "✖" != (L[actX][actY + 1]) & "\033[37m" + "⚪" != (L[actX][actY + 1]) & (actX != prevX | actY + 1 != prevY)) {
                        if (op1Llena) {
                            op2X = actX;
                            op2Y = actY + 1;
                        } else {
                            op1X = actX;
                            op1Y = actY + 1;
                            op1Llena = true;
                        }

                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY - 1]) & "\033[31m" + "✖" != (L[actX][actY - 1]) & "\033[37m" + "⚪" != (L[actX][actY - 1]) & (actX != prevX | actY - 1 != prevY)) {
                        if (op1Llena) {
                            op2X = actX;
                            op2Y = actY - 1;
                        } else {
                            op1X = actX;
                            op1Y = actY - 1;
                        }
                    }
                    if ("\033[35m" + "⬛" != (L[actX - 1][actY]) & "\033[31m" + "✖" != (L[actX - 1][actY]) & "\033[37m" + "⚪" != (L[actX - 1][actY]) & (actX - 1 != prevX | actY != prevY)) {
                        op2X = actX - 1;
                        op2Y = actY;
                    }
                    if (!pruebaSolucion(actX, actY, op1X, op1Y, L, n, inf)) {
                        if ("\033[31m" + "✖" != (L[op2X][op2Y]) & "\033[37m" + "⚪" != (L[op2X][op2Y])) {
                            if (!pruebaSolucion(actX, actY, op2X, op2Y, L, n, inf)) {
                                L[actX][actY] = "\033[31m" + "✖";
                                return false;
                            } else {
                                L[actX][actY] = "\033[32m" + "⚫";
                                return true;
                            }
                        } else {
                            L[actX][actY] = "\033[31m" + "✖";
                            return false;
                        }
                    } else {
                        L[actX][actY] = "\033[32m" + "⚫";
                        return true;
                    }
                }
                case 3 -> {
                    op1Llena = false;
                    op2Llena = false;
                    if ("\033[35m" + "⬛" != (L[actX + 1][actY]) & "\033[31m" + "✖" != (L[actX + 1][actY]) & "\033[37m" + "⚪" != (L[actX + 1][actY]) & (actX + 1 != prevX | actY != prevY)) {
                        op1X = actX + 1;
                        op1Y = actY;
                        op1Llena = true;
                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY + 1]) & "\033[31m" + "✖" != (L[actX][actY + 1]) & "\033[37m" + "⚪" != (L[actX][actY + 1]) & (actX != prevX | actY + 1 != prevY)) {
                        if (op1Llena) {
                            op2X = actX;
                            op2Y = actY + 1;
                            op2Llena = true;
                        } else {
                            op1X = actX;
                            op1Y = actY + 1;
                        }

                    }
                    if ("\033[35m" + "⬛" != (L[actX][actY - 1]) & "\033[31m" + "✖" != (L[actX][actY - 1]) & "\033[37m" + "⚪" != (L[actX][actY - 1]) & (actX != prevX | actY - 1 != prevY)) {
                        if (op2Llena) {
                            op3X = actX;
                            op3Y = actY - 1;
                        } else {
                            op2X = actX;
                            op2Y = actY - 1;
                        }
                    }
                    if ("\033[35m" + "⬛" != (L[actX - 1][actY]) & "\033[31m" + "✖" != (L[actX - 1][actY]) & "\033[37m" + "⚪" != (L[actX - 1][actY]) & (actX - 1 != prevX | actY != prevY)) {
                        op3X = actX - 1;
                        op3Y = actY;
                    }
                    if (!pruebaSolucion(actX, actY, op1X, op1Y, L, n, inf)) {
                        if ("\033[31m" + "✖" != (L[op2X][op2Y]) & "\033[37m" + "⚪" != (L[op2X][op2Y])) {
                            if (!pruebaSolucion(actX, actY, op2X, op2Y, L, n, inf)) {
                                if ("\033[31m" + "✖" != (L[op3X][op3Y]) & "\033[37m" + "⚪" != (L[op3X][op3Y])) {
                                    if (!pruebaSolucion(actX, actY, op3X, op3Y, L, n, inf)) {
                                        L[actX][actY] = "\033[31m" + "✖";
                                        return false;
                                    } else {

                                        L[actX][actY] = "\033[32m" + "⚫";
                                        return true;
                                    }
                                } else {
                                    L[actX][actY] = "\033[31m" + "✖";
                                    return false;
                                }
                            } else {

                                L[actX][actY] = "\033[32m" + "⚫";
                                return true;
                            }
                        } else {
                            L[actX][actY] = "\033[31m" + "✖";
                            return false;
                        }
                    } else {
                        L[actX][actY] = "\033[32m" + "⚫";
                        return true;
                    }
                }
            }
        }
        L[actX][actY] = "\033[31m" + "✖";
        return false;
    }

    // Método para comprobar si es posible resolver el laberinto
    public static void comprobarPosible(String[][] L, String[][] Copy, int[] n, int[] inf) {
        generarLaberinto(L, n, 0, 0, inf);
        copiarMatriz(L, Copy, n, 0, 0);
        if (pruebaSolucion(inf[1], inf[0], inf[1], inf[0], L, n, inf)) {
            dibujarSolucion(inf[1], inf[0], inf[1], inf[0], Copy, n, inf);
        } else {
            comprobarPosible(L, Copy, n, inf);
        }
    }
 // Este método copiarMatriz se encarga de copiar los elementos de una matriz L 
    public static void copiarMatriz(String[][] L, String[][] Copy, int[] n, int i, int j) {
        if (i < n[0]) {
            if (j < n[0]) {
                Copy[i][j] = L[i][j];
                copiarMatriz(L, Copy, n, i, j + 1);
            } else {
                copiarMatriz(L, Copy, n, i + 1, 0);
            }
        }
    }
//Este método validarInFin parece encargarse de validar las coordenadas del punto inicial y final de un laberinto
    public static void validarInFin(int[] inf, int infin, int[] n) {
        if (infin == 0) {
            System.out.println("Digite las coordenadas de el punto inicial (Debe estar en una frontera de el laberinto " + (n[0] - 2) + "x" + (n[0] - 2) + ")");
            System.out.println("Coordenadas en X:");
            inf[0] = sc.nextInt();
            System.out.println("Coordenadas en Y:");
            inf[1] = sc.nextInt();

            if ((inf[0] != n[0] - 2 & inf[1] != n[0] - 2 & inf[0] != 1 & inf[1] != 1) | inf[0] > n[0] - 2 | inf[1] > n[0] - 2 | inf[0] < 1 | inf[1] < 1) {
                validarInFin(inf, infin, n);
            }
        }
        if (infin == 1) {
            System.out.println("Digite las coordenadas de el punto final (Debe estar en una frontera de el laberinto " + (n[0] - 2) + "x" + (n[0] - 2) + ")");
            System.out.println("Coordenadas en X:");
            inf[2] = sc.nextInt();
            System.out.println("Coordenadas en Y:");
            inf[3] = sc.nextInt();

            if ((inf[2] != n[0] - 2 & inf[3] != n[0] - 2 & inf[2] != 1 & inf[3] != 1) | inf[2] > n[0] - 2 | inf[3] > n[0] - 2 | inf[2] < 1 | inf[3] < 1) {
                validarInFin(inf, infin, n);
            }
        }
    }
//Este método, probarTamaño, parece encargarse de solicitar al usuario el tamaño del laberinto y validar que esté dentro de los límites establecidos.
    public static void probarTamaño(int[] inf, int[] n) {

        System.out.println("Digite el tamaño del laberinto (Debe ser de minimo 1x1 y maximo 25x25): ");
        n[0]= sc.nextInt();
        if (n[0] > 25 | n[0] < 1) {
            probarTamaño(inf, n);
        }else{
        n[0] = n[0] + 2;
        }
    }
// Función principal main donde inicia la ejecución del programa
    public static void main(String[] args) {
        String L[][] = new String[100][100];
        String Copy[][] = new String[100][100];
        int inf[] = new int[4];
        int n[] = new int[1];
        n[0] = 0;
        probarTamaño(inf, n);
        validarInFin(inf, 0, n);
        validarInFin(inf, 1, n);
        comprobarPosible(L, Copy, n, inf);
    }

///     escribirLaberinto(L, n, 0, 0);
    /// dibujarSolucion(0, 0, 1, 1, L, n);
/// generarLaberinto(L, n, 0, 0);
    ///    escribirLaberinto(L, n, 0, 0);   
    ///  dibujarSolucion(0, 0, 1, 1, L, n);
}

